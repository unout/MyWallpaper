package com.example.katy.mywallpaper;

import android.graphics.Paint;

class MyCircle {

    int x;
    int y;
    int radius;
    Paint color;

    public MyCircle(int x, int y, int radius, Paint color) {
        this.x = x;
        this.y = y;
        this.radius = radius;
        this.color = color;
    }
}
